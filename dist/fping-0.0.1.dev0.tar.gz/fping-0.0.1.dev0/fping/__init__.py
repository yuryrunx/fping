from .main import FPing


__version__ = '0.0.1-dev'
__author__ = 'Yury'
__licence__ = 'Free'
#__email__ = 'yury@example.com'



